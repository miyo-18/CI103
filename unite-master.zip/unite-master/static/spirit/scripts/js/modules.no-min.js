
/*
    Simple module system
 */

(function() {
  window.stModules = {};

}).call(this);
