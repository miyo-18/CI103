import os

from django.core.wsgi import get_wsgi_application

#Default WSGI settings for spirit
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'unite.settings')

application = get_wsgi_application()
